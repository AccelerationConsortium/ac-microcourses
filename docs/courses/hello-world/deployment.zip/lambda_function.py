import os
import json
from pymongo import MongoClient

username = "test-user-insert-only"

# password set as environment variable to help keep secure (even though it's
# made public in the example, i.e., to demonstrate keeping it secure)
password = os.environ.get("PASSWORD")

# atlas_uri as copy-pasted from MongoDB
atlas_uri = "mongodb+srv://<db_username>:<db_password>@test-cluster.c5jgpni.mongodb.net/?retryWrites=true&w=majority&appName=test-cluster"

# using find-replace instead of f-string to make it easier to drop-in
# the copy-pasted line above
atlas_uri = atlas_uri.replace("<db_username>", username)
atlas_uri = atlas_uri.replace("<db_password>", password)

client = MongoClient(host=atlas_uri)


def lambda_handler(event, context):
    try:
        print(event)
        payload = json.loads(event["body"])

        document = payload["document"]
        print(document)

        # You can restrict the MongoDB user to only access certain databases or
        # collections, but if you're worried about potential risk in accessing other
        # collections, an alternative to what's shown below is to hardcode the db
        # and collection names into the AWS Lambda function (as-is, it receives
        # these names)
        db_name = payload["database"]
        collection_name = payload["collection"]

        db = client[db_name]
        collection = db[collection_name]

        # Insert document
        print(f"sending document to {db_name}:{collection_name}")
        result = collection.insert_one(document)

        return {
            "statusCode": 200,
            "body": json.dumps({"message": f"Document inserted successfully to {db_name}:{collection_name} with id {result.inserted_id}"}),
        }
    except Exception as e:
        # This helps with providing some meaningful feedback instead of e.g., "Internal Server Error" when invoking the Python function
        print(e)
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Received error: {str(e)}. Check the AWS Lambda logs (On the function page, navigate to 'test' then 'CloudWatch Logs Live Tail', select the log group, click start, and then run the request again to monitor the full error)"}),
        }


