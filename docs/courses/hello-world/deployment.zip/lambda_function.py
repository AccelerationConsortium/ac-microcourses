import os
import json
from pymongo import MongoClient

username = "test-user-insert-only"

# password set as environment variable to help keep secure (even though it's made public in the example, i.e., to demonstrate keeping it secure)

password = os.environ.get("PASSWORD")
# atlas_uri as copy-pasted from MongoDB

atlas_uri = "mongodb+srv://<db_username>:<db_password>@test-cluster.c5jgpni.mongodb.net/?retryWrites=true&w=majority&appName=test-cluster"

# using find-replace instead of f-string to make it easier to drop-in copy-pasted line above
atlas_uri = atlas_uri.replace("<db_username>", username)
atlas_uri = atlas_uri.replace("<db_password>", password)

client = MongoClient(host=atlas_uri)


# Define database and collection outside the handler for reuse
# NOTE: technically could have these be inputs to the lambda function, but this comes with security issues (i.e., scope spans more than just one db or collection)
db_name = "test-db"
collection_name = "write-to-me"
db = client[db_name]
collection = db[collection_name]


def lambda_handler(event, context):
    print(event)
    document = json.loads(event["body"])
    print(document)

    # Insert document

    result = collection.insert_one(document)

    return {
        "statusCode": 200,
        "body": json.dumps({"message": f"Document inserted successfully: {document}"}),
    }
